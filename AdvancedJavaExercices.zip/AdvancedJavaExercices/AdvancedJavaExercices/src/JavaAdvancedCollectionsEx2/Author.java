package JavaAdvancedCollectionsEx2;

import java.util.Objects;

public class Author {
    private String lName;
    private String fName;
    private char genre;

    public Author(String lName, String fName, char genre) {
        this.lName = lName;
        this.fName = fName;
        this.genre = genre;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public char getGenre() {
        return genre;
    }

    public void setGenre(char genre) {
        this.genre = genre;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Author author = (Author) o;
        return genre == author.genre && Objects.equals(lName, author.lName) && Objects.equals(fName, author.fName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lName, fName, genre);
    }

    @Override
    public String toString() {
        return "Author{" +
                "lName='" + lName + '\'' +
                ", fName='" + fName + '\'' +
                ", gender='" + genre + '\'' +
                '}';
    }
}
