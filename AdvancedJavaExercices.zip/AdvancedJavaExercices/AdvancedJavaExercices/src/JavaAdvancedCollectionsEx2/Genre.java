package JavaAdvancedCollectionsEx2;

public enum Genre {
    ACTION, FANTASY, CRIME
}
