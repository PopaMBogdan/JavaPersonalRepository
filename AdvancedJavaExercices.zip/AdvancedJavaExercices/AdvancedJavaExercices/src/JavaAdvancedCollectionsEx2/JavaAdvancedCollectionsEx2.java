package JavaAdvancedCollectionsEx2;

import java.util.Arrays;
import java.util.Stack;

public class JavaAdvancedCollectionsEx2 {
    public static void main(String[] args) {

        Author author1 = new Author("John", "Smith", 'M');
        Author author2 = new Author("Jessica", "Albana", 'F');
        Author author3 = new Author("Roger", "Moore", 'M');
        Author author4 = new Author("Catherin", "Nadie", 'F');
        Book book1 = new Book("Book 1", 34, 2000, Arrays.asList(author1), Genre.FANTASY);
        Book book2 = new Book("Book 1", 56, 1999, Arrays.asList(author2, author3, author4), Genre.ACTION);
        BookList bookList = new BookList();
        bookList.add(book1);
        bookList.add(book2);
        System.out.println(bookList.findByAuthor(author2));
        System.out.println(bookList.getAll());
        System.out.println(bookList.findMostExpensiveBook());
        System.out.println(bookList.sortByTitleAsc());
        System.out.println(bookList.sortByTitleDesc());
        //task4
        BookServiceExt bookService = new BookServiceExt();
        bookService.add(book1);
        bookService.add(book2);
        System.out.println(bookService.mapBooks());
        //task 5
        BookServiceExt2 bookServiceExt2 = new BookServiceExt2();
        bookService.add(book1);
        bookService.add(book2);
        Stack<Book> bookStack = bookServiceExt2.createBookStack();
        while (!bookStack.isEmpty()) {
            System.out.println(bookStack.pop());
        }
    }
}
