package JavaAdvancedEnumTypesEx1;

public class JavaAdvancedEnumTypesEx1 {
    public static void main(String[] args) {

        System.out.println("Saturday is holiday: " + Weekday.SATURDAY.isHoliday());
        System.out.println("Firday is weekday: " + Weekday.FRIDAY.isWeekDay());
        Weekday.TUESDAY.witchIsGreater(Weekday.MONDAY);
    }

}

