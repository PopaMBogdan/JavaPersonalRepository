package JavaAdvancedEnumTypesEx2;

public class JavaAdvancedEnumTypesEx2 {
    public static void main(String[] args) {
        PackageSize packageSize1 = PackageSize.getPackageSize(41, 60);
        System.out.println("packetsize 1 is " + packageSize1);
        PackageSize packageSize2 = PackageSize.getPackageSize(92, 135);
        System.out.println("packetsize 2 is " + packageSize2);
        PackageSize packageSize3 = PackageSize.getPackageSize(143, 235);
        System.out.println("packetsize 3 is " + packageSize3);
        PackageSize packageSize4 = PackageSize.getPackageSize(33, 260);
        System.out.println("packetsize 4 is " + packageSize4);
    }
}
