package JavaAdvancedEnumTypesEx2;

public enum PackageSize {
    SMALL(40, 90),
    MEDIUM(90, 140),
    LARGE(140, 250),
    UNKNOWN(0, 0);

    private int MinPackageSizeInCm;
    private int MaxPackageSizeInCm;

    PackageSize(int minPackageSizeInCm, int maxPackageSizeInCm) {
        MinPackageSizeInCm = minPackageSizeInCm;
        MaxPackageSizeInCm = maxPackageSizeInCm;
    }

    public static PackageSize getPackageSize(int minPackageSizeInCm, int maxPackageSizeInCm) {
        for (PackageSize packageSize : values()) {
            if (minPackageSizeInCm >= packageSize.MinPackageSizeInCm && maxPackageSizeInCm < packageSize.MaxPackageSizeInCm) {
                return packageSize;
            }
        }
        return UNKNOWN;

    }

    public int getMinPackageSizeInCm() {
        return MinPackageSizeInCm;
    }

    public void setMinPackageSizeInCm(int minPackageSizeInCm) {
        MinPackageSizeInCm = minPackageSizeInCm;
    }

    public int getMaxPackageSizeInCm() {
        return MaxPackageSizeInCm;
    }

    public void setMaxPackageSizeInCm(int maxPackageSizeInCm) {
        MaxPackageSizeInCm = maxPackageSizeInCm;
    }
}
