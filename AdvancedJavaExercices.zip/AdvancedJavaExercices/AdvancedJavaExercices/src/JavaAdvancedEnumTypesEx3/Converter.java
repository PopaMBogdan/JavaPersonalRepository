package JavaAdvancedEnumTypesEx3;

public interface Converter {
    float convert(float tempIn);

}
