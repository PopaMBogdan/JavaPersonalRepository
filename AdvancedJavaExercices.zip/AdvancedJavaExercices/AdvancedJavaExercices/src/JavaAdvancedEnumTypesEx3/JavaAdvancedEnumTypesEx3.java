package JavaAdvancedEnumTypesEx3;

public class JavaAdvancedEnumTypesEx3 {
    public static void main(String[] args) {

        float convertedTemp1 = TemperatureConverter.convertTemperature('C', 'K', 34);
        System.out.println("conversion C to K: " + convertedTemp1);
        float convertedTemp2 = TemperatureConverter.convertTemperature('C', 'F', 34);
        System.out.println("conversion C to F: " + convertedTemp2);
        float convertedTemp3 = TemperatureConverter.convertTemperature('K', 'C', 34);
        System.out.println("conversion K to C: " + convertedTemp3);
        float convertedTemp4 = TemperatureConverter.convertTemperature('F', 'C', 34);
        System.out.println("conversion F to C: " + convertedTemp4);
        float convertedTemp5 = TemperatureConverter.convertTemperature('F', 'K', 34);
        System.out.println("conversion F to K: " + convertedTemp5);
        float convertedTemp6 = TemperatureConverter.convertTemperature('K', 'F', 34);
        System.out.println("conversion K to F: " + convertedTemp6);
    }

}

