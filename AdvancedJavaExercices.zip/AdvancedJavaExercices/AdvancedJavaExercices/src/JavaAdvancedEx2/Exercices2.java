package JavaAdvancedEx2;

public class Exercices2 {
    public static void main(String[] args) {
        Person student = new Student("IT", 3, 1500f);
        Person lecturer = new Lecturer("Computer programmer", 5000f);
        Person person = new Person("Gigi Contra", "La el acasa");
        System.out.println(student);
        System.out.println(lecturer);
        System.out.println(person);


    }

}
