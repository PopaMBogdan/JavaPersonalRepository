
package JavaAdvancedEx2;

public class Lecturer extends Person {

    private String specialization;
    private float Salary;

    public Lecturer(String specialization, float salary) {
        this.specialization = specialization;
        Salary = salary;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public float getSalary() {
        return Salary;
    }

    public void setSalary(float salary) {
        Salary = salary;
    }

    @Override
    public String toString() {
        return "Lecturer{" +
                "specialization='" + specialization + '\'' +
                ", Salary=" + Salary +
                ", name='" + "Jack Ripper" + '\'' +
                ", adress='" + "Socola 1" + '\'' +
                '}';
    }
}

