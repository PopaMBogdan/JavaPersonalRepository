package JavaAdvancedEx2;


public class Person {
    public String name, adress;

    public Person() {
    }

    public Person(String name, String adress) {
        this.name = name;
        this.adress = adress;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        name = name;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        adress = adress;
    }

    @Override
    public String toString() {
        return "JavaAdvancedEx2.Exercices2.Person{" +
                "name='" + name + '\'' +
                ", adress='" + adress + '\'' +
                '}';
    }
}

