package JavaAdvancedEx2;

class Student extends Person {
    private String typOfStudy;
    private int yearOfStudy;
    private float priceOfStudy;

    public Student(String typOfStudy, int yearOfStudy, float priceOfStudy) {
        this.typOfStudy = typOfStudy;
        this.yearOfStudy = yearOfStudy;
        this.priceOfStudy = priceOfStudy;
    }

    public String getTypOfStudy() {
        return typOfStudy;
    }

    public void setTypOfStudy(String typOfStudy) {
        this.typOfStudy = typOfStudy;
    }

    public int getYearOfStudy() {
        return yearOfStudy;
    }

    public void setYearOfStudy(int yearOfStudy) {
        this.yearOfStudy = yearOfStudy;
    }

    public double getPriceOfStudy() {
        return priceOfStudy;
    }

    public void setPriceOfStudy(float priceOfStudy) {
        this.priceOfStudy = priceOfStudy;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + "Johny Cash" + '\'' +
                ", adress='" + "Salciei 40" + '\'' +
                ", typOfStudy='" + typOfStudy + '\'' +
                ", yearOfStudy=" + yearOfStudy +
                ", priceOfStudy=" + priceOfStudy +
                '}';
    }
}
