package JavaAdvancedEx3;

public class Circle extends Shape {
    private float radius;

    public Circle() {
        this.color = color;
        this.isFilled = isFilled;
        this.radius = radius;
    }

    public Circle(String color, boolean isFilled, float radius) {
        this.color = color;
        this.isFilled = isFilled;
        this.radius = radius;
    }

    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    @Override
    public String toString() {
        return String.format("Circle with radius= %f which is a subclass off %s", radius, super.toString());
    }
}
