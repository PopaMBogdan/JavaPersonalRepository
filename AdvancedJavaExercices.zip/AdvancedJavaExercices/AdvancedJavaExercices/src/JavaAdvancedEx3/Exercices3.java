package JavaAdvancedEx3;

public class Exercices3 {
    public static void main(String[] args) {
        Shape shape = new Shape("red", false);
        System.out.println(shape);
        Circle circle = new Circle("red", false, 2.5f);
        System.out.println(circle);
        Rectangle rectangle = new Rectangle("blue", false, 1.0, 1.0);
        System.out.println(rectangle);
        Square square = new Square("gren", false, 1.0);
        System.out.println(square);
    }

}
