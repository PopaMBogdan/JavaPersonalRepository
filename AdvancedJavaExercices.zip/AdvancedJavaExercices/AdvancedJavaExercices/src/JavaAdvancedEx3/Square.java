package JavaAdvancedEx3;

public class Square extends Rectangle {


    public Square(String color, boolean isFilled, double size) {
        super(color, isFilled, size, size);
    }

    public void SetWidth(double width) {
        super.setWidth(width);
        super.setLength(width);
    }

    public void SetLength(double length) {
        super.setLength(length);
        super.setLength(length);
    }


    @Override
    public String toString() {
        return String.format("Square with wide= %f and length= %f which is a subclass of %s", getLength(), getWidth(), super.toString());
    }
}
