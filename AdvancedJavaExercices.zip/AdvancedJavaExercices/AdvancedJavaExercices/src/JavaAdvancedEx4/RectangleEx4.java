package JavaAdvancedEx4;

public class RectangleEx4 extends ShapeEx4 {

    private double length, width;

    public RectangleEx4() {

        this.length = 1;
        this.width = 1;
    }

    @Override
    public float getArea() {
        return (float) (length * width);
    }

    @Override
    public float getPerimeter() {
        return (float) (2 * length + 2 * width);
    }

    public RectangleEx4(String color, boolean isFilled, double length, double width) {
        super(color, false);
        this.length = length;
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }


    @Override
    public String toString() {
        return String.format("Rectangle with wide= %f and legth= %f which is a subclass of %s", length, width, super.toString());
    }

}
