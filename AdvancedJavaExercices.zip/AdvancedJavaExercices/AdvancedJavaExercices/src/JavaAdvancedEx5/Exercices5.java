package JavaAdvancedEx5;

public class Exercices5 {
    public static void main(String[] args) {
        Line line = new Line(10, 20, 30, 40);
        System.out.println(line.getLength());
        System.out.println(line.getMiddlePoint());
    }
}

