package JavaAdvancedEx6;

public class Exercices6 {
    public static void main(String[] args) {

        MovablePoint p1 = new MovablePoint(10, 10, 5, 5);
        System.out.println(p1);
        p1.moveUp();
        p1.moveLeft();
        System.out.println(p1);

        MovableCircle c1 = new MovableCircle(10, 10, 5, 5, 2.3f);
        System.out.println(c1);
        c1.moveUp();
        c1.moveRight();
        System.out.println(c1);
    }
}
