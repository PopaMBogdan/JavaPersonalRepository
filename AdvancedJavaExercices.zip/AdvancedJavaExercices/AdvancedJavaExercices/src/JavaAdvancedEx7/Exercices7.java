package JavaAdvancedEx7;

public class Exercices7 {
    public static void main(String[] args) {

        Circle circle = new Circle(14);
        circle.getArea();
        circle.getPerimetral();
        System.out.println(circle.getArea());
        System.out.println(circle.getPerimetral());

        ResizebleCircle resizebleCircle = new ResizebleCircle(40);
        resizebleCircle.getArea();
        resizebleCircle.getPerimetral();
        System.out.println(resizebleCircle.getArea());
        System.out.println(resizebleCircle.getPerimetral());

    }
}
