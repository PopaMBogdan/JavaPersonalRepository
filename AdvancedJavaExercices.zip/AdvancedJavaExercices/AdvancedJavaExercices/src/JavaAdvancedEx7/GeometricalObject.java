package JavaAdvancedEx7;

public interface GeometricalObject {
    double getPerimetral();

    double getArea();

}
