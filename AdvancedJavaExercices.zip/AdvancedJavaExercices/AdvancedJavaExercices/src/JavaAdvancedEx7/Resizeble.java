package JavaAdvancedEx7;

public interface Resizeble {
    void resize(int percent);
}
