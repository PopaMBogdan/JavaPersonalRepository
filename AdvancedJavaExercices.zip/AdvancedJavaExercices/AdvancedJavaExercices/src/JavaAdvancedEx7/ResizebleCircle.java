package JavaAdvancedEx7;

public class ResizebleCircle extends Circle implements Resizeble {
    double radius;

    public ResizebleCircle(double radius) {
        super(radius);
        this.radius = radius;
    }

    @Override
    public void resize(int percent) {
        radius = (radius * percent);
    }

    @Override
    public String toString() {
        return "ResizebleCircle{" +
                "radius=" + radius +
                '}';
    }
}
