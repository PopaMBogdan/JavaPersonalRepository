package JavaAdvancedExercices.ShopImitation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Basket {

    private Map<Integer, Integer> cantitatiProduse = new HashMap<>();



    private final List<Product> products = new ArrayList<>();

    public void addItem(Product product, int cantitate) {
        if(products.contains(product.hashCode()));
        products.add(product);
        cantitatiProduse.put(product.getId(), cantitate);
    }

    public void removeItem(Product product, int id) {
        products.removeIf(productList -> product.getId() == id);
        cantitatiProduse.remove(product.getId());
    }

    public void incrementQuantity(Product product, int delta){  //delta este diferenta de cantitate (cu cat o incrementam)
        int quantity = cantitatiProduse.getOrDefault(product.getId(),0) + delta; // getOrDefault = aduce product.getId(), dar daca nu exista produs returneaza by default valoarea zero.
        cantitatiProduse.put(product.getId(),quantity);
    }

    public void decrementQuantity(Product product, int delta){
        int quantity = cantitatiProduse.getOrDefault(product.getId(),0) - delta;
        cantitatiProduse.put(product.getId(),quantity);
    }

    public List<Product> getProducts() {
        List<Product> list = new ArrayList<>(products);
        return list;
    }

    public double getTotalPrice(){
        return products.stream().mapToDouble(product -> product.getPrice() * cantitatiProduse.get(product.getId())).sum();
    }


}
