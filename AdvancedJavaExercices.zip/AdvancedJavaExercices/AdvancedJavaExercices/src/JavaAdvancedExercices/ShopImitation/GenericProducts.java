package JavaAdvancedExercices.ShopImitation;

import java.time.LocalDate;

public class GenericProducts implements Product {

    String name;
    final int id;
    final double price;
    LocalDate availibilityDate;
    Suplier suplier;


    public GenericProducts(int id, Suplier suplier) {
        this.suplier = suplier;
        this.id = id;
        this.price = suplier.getPriceForProduct(this);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public void setAvailibilityDate(LocalDate availibilityDate) {
        this.availibilityDate = availibilityDate;
    }

    @Override
    public int getId() {
        return 0;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public boolean getAvailabilityDate(LocalDate date) {
        return false;
    }
}
