package JavaAdvancedExercices.ShopImitation;

public class Main {

    public static void main(String[] args) {

        Product food = new GenericProducts(2,new Suplier());
        Product drink = new GenericProducts(3,new Suplier());
        Product fruits= new GenericProducts(4,new Suplier());


        Basket basket = new Basket();
        basket.addItem(food,2);
        basket.addItem(drink,3);
        basket.addItem(fruits,5);

        System.out.println(basket.getProducts());
        basket.removeItem(food,2);

        basket.incrementQuantity(drink, 2);
        //System.out.println(basket.getQuantities());


        OrderService orderService = new OrderService(basket);
        System.out.println("pret totual " +basket.getTotalPrice() );
    }


}
