package JavaAdvancedExercices.ShopImitation;

public class OrderService  {

    private Basket basket;


    public OrderService(Basket basket) {
        this.basket = basket;
    }

    public double getTotalPrice(){
        return basket.getTotalPrice();
    }
}
