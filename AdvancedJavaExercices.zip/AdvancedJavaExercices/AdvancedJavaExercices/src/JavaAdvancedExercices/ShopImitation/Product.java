package JavaAdvancedExercices.ShopImitation;

import java.time.LocalDate;
import java.util.Date;

public interface Product {

    int getId();


    double getPrice();

    boolean getAvailabilityDate(LocalDate date);
}
