package JavaAdvancedExercices.ShopImitation;

import java.util.Random;

public class Suplier {

    double getPriceForProduct(Product product) {
        Random r = new Random();
        double numar = r.nextDouble();

        return numar * product.getId();
    }
}
