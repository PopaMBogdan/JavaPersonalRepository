package JavaAdvancedExercices.averageList;

import java.util.List;

public class Average {

    public Double average(List<Integer> list){
        return list.stream().mapToDouble(value -> value).average().getAsDouble(); //mapToDouble transforma stringul in double pentru a putea apela metoda .average();
    }
}
