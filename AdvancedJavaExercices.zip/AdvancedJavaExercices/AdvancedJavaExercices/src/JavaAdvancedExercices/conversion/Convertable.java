package JavaAdvancedExercices.conversion;

import java.util.ArrayList;
import java.util.List;

public interface Convertable
{
    default List<String> upperAllElements(final List<String> oldList)
    {
        if(oldList == null || oldList.isEmpty())
        {
            return oldList;
        }

        List<String> newList = new ArrayList<>();

        oldList.forEach(element -> newList.add(element.toUpperCase()));

        return newList;
    }

    List<String> createList();
}
