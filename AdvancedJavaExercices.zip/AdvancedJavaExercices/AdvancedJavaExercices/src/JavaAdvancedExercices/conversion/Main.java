package JavaAdvancedExercices.conversion;

import java.util.List;

public class Main
{
    public static void main(String[] args)
    {
        Convertable cv = new ReadStringList();
        List<String> simpleList = cv.createList();

        simpleList = cv.upperAllElements(simpleList);

        System.out.println(simpleList);
    }
}
