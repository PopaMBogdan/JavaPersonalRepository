package JavaAdvancedExercices.conversion;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ReadStringList implements Convertable
{
    private final Scanner scText = new Scanner(System.in);
    private final Scanner scNumber = new Scanner(System.in);

    public List<String> createList()
    {
        List<String> newStringList = new ArrayList<>();

        int size = getSize();
        for(int i = 0; i < size; i++)
        {
            System.out.print("Adaugati elementul " + (i + 1) + ": ");
            newStringList.add(scText.nextLine());
        }

        return newStringList;
    }

    private int getSize()
    {
        int size = 0;

        do
        {
            System.out.print("Introduceti dimensiunea listei (minim 1): ");
            size = scNumber.nextInt();
        } while (size < 1);

        return size;
    }
}
