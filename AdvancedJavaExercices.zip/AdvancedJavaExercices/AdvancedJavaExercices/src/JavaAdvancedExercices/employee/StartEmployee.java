package JavaAdvancedExercices.employee;
import java.util.ArrayList;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;


public class StartEmployee {

    static Employee employee1 = new Employee("John","emp011",20000.00);
    static Employee employee2 = new Employee("Mark","emp012",40000.00);
    static Employee employee4 = new Employee("George","emp013",30000.00);
    static Employee employee5 = new Employee("William","emp015",60000.00);


    public static void main(String[] args) {

        List<Employee> employeeList = new ArrayList<>();



        employeeList.add(employee1);
        employeeList.add(employee2);
        employeeList.add(employee4);
        employeeList.add(employee5);

        System.out.println(employeeList);

       System.out.println(new EmployeeSelection().select(employeeList));



        List<Employee> employeesSorted = new ArrayList<>();

        employeesSorted.add(employee1);
        employeesSorted.add(employee2);
        employeesSorted.add(employee4);
        employeesSorted.add(employee5);

        System.out.println(employeesSorted.stream().sorted(Comparator.comparing(Employee::getName)).collect(Collectors.toList()));

    }
}
