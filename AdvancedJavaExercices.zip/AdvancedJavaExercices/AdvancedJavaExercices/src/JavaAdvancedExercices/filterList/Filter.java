package JavaAdvancedExercices.stringTransformer;

import java.util.List;

public interface Filter {
    List<String> filterList(List<String> list);
    void showAllResults(List<String> list);


}
