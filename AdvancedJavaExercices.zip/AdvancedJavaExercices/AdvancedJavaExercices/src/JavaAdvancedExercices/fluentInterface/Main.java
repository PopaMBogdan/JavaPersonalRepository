package JavaAdvancedExercices.fluentInterface;

public class Main {

    public static void main(String[] args) {

        Car car = new Car();
        car.setColor("Black").setName("Dacia").setPrice(13999.99);

        System.out.println(car.getColor() + "/" +  car.getPrice()+ "/" + car.getName());
    }
}
