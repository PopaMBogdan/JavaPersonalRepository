package JavaAdvancedExercices.generice;

public class ReverseTest {
}
