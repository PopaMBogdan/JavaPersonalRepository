package JavaAdvancedExercices.localDate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class LocalDateExercices {
    public static void main(String[] args) {

        LocalDate localDate = LocalDate.now(); // zzllaaaa
        LocalDateTime localTime = LocalDateTime.now(); // data + ora

        System.out.println(localDate);
        System.out.println(localTime);

        ZonedDateTime zoneTime = localDate.atStartOfDay(ZoneId.systemDefault());
        System.out.println(zoneTime.toLocalTime().getHour());
    }
}
