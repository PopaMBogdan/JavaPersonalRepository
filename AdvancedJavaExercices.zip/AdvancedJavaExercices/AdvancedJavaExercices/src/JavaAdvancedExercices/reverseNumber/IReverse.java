package JavaAdvancedExercices.reverseNumber;

public interface IReverse {

    int doReverse(int numarIntrouds);

}
