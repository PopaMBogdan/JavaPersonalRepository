package JavaAdvancedExercices.reverseNumber;

public class Main {
    public static void main(String[] args) {

        Read cititorNumere = new Read();

        int numarIntrodus = cititorNumere.readNumber();

        IReverse invertor = new ReverseNumber();
        System.out.println("Numarul inversat este: " + invertor.doReverse(numarIntrodus));
        invertor = new ReverseString();
        System.out.println("Numarul inversat este (string): " + invertor.doReverse(cititorNumere.readNumber()));
    }

}
