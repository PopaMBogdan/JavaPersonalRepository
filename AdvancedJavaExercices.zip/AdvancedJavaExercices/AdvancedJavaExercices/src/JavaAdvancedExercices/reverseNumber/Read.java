package JavaAdvancedExercices.reverseNumber;

import java.util.Scanner;

public class Read {

    public int readNumber() {
        System.out.print("Introduceti numarul de la tastatura: ");
        Scanner numere = new Scanner(System.in);
        return numere.nextInt();
    }
}
