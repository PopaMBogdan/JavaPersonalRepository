package JavaAdvancedExercices.reverseNumber;

import java.util.Scanner;

public class ReadInput {



    public int readNumber(){
        System.out.println("Introduceti numarul de la tastatura: ");
        Scanner numere = new Scanner(System.in);
        return numere.nextInt();
    }

}
