package JavaAdvancedExercices.reverseNumber;

public class ReverseNumber implements IReverse {

    public int doReverse(int numarIntrodus) {
        int ultimaCifra = 0;
        int numarInversat = 0;
        while (numarIntrodus > 0) {
            ultimaCifra = numarIntrodus % 10;
            numarInversat = numarInversat * 10 + ultimaCifra;
            numarIntrodus = numarIntrodus/ 10;
            /*
            Avem numarul 2573:
            -1. se imparte numarul la 10 iar restul reprezinta ultima cifra
            -2. ultima cifra va fi prima cifra din numarul inversat.numarul inversat va fi chiar cifra
            -3. numarIntrodus devine numar inversat impartit intreg la 10
            -4. numarInversat este *10 + ultimacifra
             */
        }
        return numarInversat;
    }
}
