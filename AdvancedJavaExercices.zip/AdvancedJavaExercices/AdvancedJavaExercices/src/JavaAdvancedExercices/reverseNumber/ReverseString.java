package JavaAdvancedExercices.reverseNumber;

public class ReverseString implements IReverse {

    public int doReverse(int numarIntrouds) {
        StringBuilder sb = new StringBuilder().append(numarIntrouds);
        sb.reverse();
        return Integer.parseInt(sb.toString());
    }
}

