package exercise6;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Integer> list = Arrays.asList();
        System.out.println(StringTransformer.getStringTransformer().transformString(list));
    }
}
