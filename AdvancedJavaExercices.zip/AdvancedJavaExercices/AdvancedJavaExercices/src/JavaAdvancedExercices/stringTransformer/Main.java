package JavaAdvancedExercices.stringTransformer;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        List<Integer> list = Arrays.asList();
        System.out.println(StringTransformer.getStringTransformer());


    }

    public static class ReadArrayDimension {

        public int readDimension() {
            System.out.print("Type the dimension of array: ");
            Scanner scannerNumber = new Scanner(System.in);
            int dimensionOfArray = scannerNumber.nextInt();
            return dimensionOfArray;
        }
    }
}
