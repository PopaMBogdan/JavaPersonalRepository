package JavaAdvancedExercices.stringTransformer;

public interface Sorter {

    int[] sortArray(int[] array);

    class ShowArray {

        public void printArray(int[] array) {
            for (int i = 0; i < array.length; i++) {
                System.out.print(array[i] + " ");
            }
            System.out.println();
        }
    }
}
