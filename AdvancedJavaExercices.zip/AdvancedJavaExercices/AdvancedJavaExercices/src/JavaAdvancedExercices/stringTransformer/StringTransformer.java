package JavaAdvancedExercices.stringTransformer;

import java.util.List;

public class StringTransformer {

    private static final StringTransformer stringTransformer = new StringTransformer(); //singurul meu obiect - SINGLETON

    //e static pentru ca la pornirea aplicatiei intai se executa tot ceea ce este static si tine de clasa !!!!
    //metoda este private ==> nu se poate apela din afara pentru ca este private si astfel nu poate fi instantiata clasa din exetrior
    //se formeaza o bucla in care nu voi putea apela obiectul StringTransformer pentru ca nu am cum sa apelez constructorul !

    // codul static se executa cand fac referire la clasa respectiva
    // codul non static se executa cand fac referire la un new din clasa respectiva

    //SIGLETON - 3 elemente:
    // - camp privat static pentru singura instantei
    // - metoda statica care returneaza acea singura instanta
    // - constructor privat

    public static StringTransformer getStringTransformer(){
           return stringTransformer;
    }

    private StringTransformer(){

    }

    public String transformString(List<Integer> list){
        if(list == null){
            return "";

        }
        return list.stream().map(number ->{
            if(number%2 == 0){
                return "e" + number;
            }
                return "o" + number;
        }).reduce((result,item) -> result + "," + item).orElse("");
    }

}
