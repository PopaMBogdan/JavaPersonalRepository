package JavaClassAndInterfaceEx1;

public class JavaClassAndInterfaceEx1 {


    public static void main(String[] args) {
        UserValidator userValidator = new UserValidator();
        String[] results = userValidator.validateEmails("bogdan.popa@partner.bmw.com", "@yahoo.com");
        System.out.println(results[0]);
        System.out.println(results[1]);
    }

}
