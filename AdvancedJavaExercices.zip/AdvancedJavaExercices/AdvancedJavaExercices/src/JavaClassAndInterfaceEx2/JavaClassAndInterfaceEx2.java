package JavaClassAndInterfaceEx2;

public class JavaClassAndInterfaceEx2 {
    public static void main(String[] args) {
        Movie movie = new MovieCreator()
                .setTitle("Star Wars")
                .setDirector("J.J Abrams")
                .setGenre("Action")
                .setYearOfRelease(2015)
                .setPublisher("Disney")
                .createMovie();
        System.out.println(movie);
    }

}
