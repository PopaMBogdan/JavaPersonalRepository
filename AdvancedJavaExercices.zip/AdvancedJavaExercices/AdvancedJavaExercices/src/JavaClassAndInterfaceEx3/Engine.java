package JavaClassAndInterfaceEx3;

public class Engine {
    private String engineType;

    public String setEngineType(String type) {
        switch (type) {
            case "economy":
                engineType = "diesel";
                break;
            case "luxury":
                engineType = "electric";
                break;
            default:
                engineType = "petrol";
        }
        return engineType;
    }

    @Override
    public String toString() {
        return "Engine{" +
                "engineType='" + engineType + '\'' +
                '}';
    }
}
