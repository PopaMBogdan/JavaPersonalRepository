package JavaClassAndInterfaceEx3;

public class JavaClassAndInterfaceEx3 {
    public static void main(String[] args) {

        Car car = new Car("Audi", "luxury");
        System.out.println(car);


    }
}
