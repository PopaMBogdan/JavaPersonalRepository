package JavaClassAndInterfaceEx4;

public class JavaClassAndInterfacesEx4 {
    public static void main(String[] args) {

        User user = new User();
        user.setName("John", new Validator<String>() {
            @Override
            public boolean validate(String input) {
                return !input.isEmpty() &&
                        Character.isUpperCase(input.charAt(0));
            }
        });

        user.setlName("Smith", new Validator<String>() {
            @Override
            public boolean validate(String input) {
                return !input.isEmpty() &&
                        Character.isUpperCase(input.charAt(0));
            }
        });

        user.setAge(30, new Validator<Integer>() {
            @Override
            public boolean validate(Integer input) {
                return input >= 0 && input < 150;
            }
        });

        user.setLogin("JohnSmith", new Validator<String>() {
            @Override
            public boolean validate(String input) {
                return input.length() == 10;
            }
        });

        user.setPassword("Peterasu1!", new Validator<String>() {
            @Override
            public boolean validate(String input) {
                return input.contains(" ! ");
            }
        });
    }
}


