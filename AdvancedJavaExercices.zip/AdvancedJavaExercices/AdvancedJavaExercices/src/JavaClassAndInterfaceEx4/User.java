package JavaClassAndInterfaceEx4;

public class User implements Validator {
    private String name;
    private String lName;
    private int age;
    private String login;
    private String password;

    public User() {
    }

    public User(String name, String lName, int age, String login, String password) {
        this.name = name;
        this.lName = lName;
        this.age = age;
        this.login = login;
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name, Validator<String> validator) {
        if (validator.validate(name))
            this.name = name;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName, Validator<String> validator) {
        if (validator.validate(lName)) {
            this.lName = lName;
        }
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age, Validator<Integer> validator) {
        if (validator.validate(age)) {
            this.age = age;
        }
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login, Validator<String> validator) {
        if (validator.validate(login)) {
            this.login = login;
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password, Validator<String> validator) {
        if (validator.validate(password)) {
            this.password = password;
        }
    }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", lName='" + lName + '\'' +
                ", age=" + age +
                ", login='" + login + '\'' +
                ", password='" + password + '\'' +
                '}';
    }


    @Override
    public boolean validate(Object input) {
        return false;
    }
}
