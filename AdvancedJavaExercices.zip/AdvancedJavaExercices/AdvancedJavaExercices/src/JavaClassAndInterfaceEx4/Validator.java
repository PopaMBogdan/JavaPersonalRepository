package JavaClassAndInterfaceEx4;

interface Validator<T> {
    boolean validate(T input);
}
