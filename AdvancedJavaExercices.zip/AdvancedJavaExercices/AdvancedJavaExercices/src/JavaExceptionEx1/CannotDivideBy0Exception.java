package JavaExceptionEx1;

public class CannotDivideBy0Exception extends Exception {

    public CannotDivideBy0Exception() {
        super("Can't divide by zero!!!");
    }
}
