package JavaExceptionEx1;

public class Divide {
    int x, y;


    public static float divide(int x, int y) throws CannotDivideBy0Exception {
        if (y == 0) {
            throw new CannotDivideBy0Exception();
        }
        return x / y;
    }

}




