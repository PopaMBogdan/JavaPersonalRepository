package JavaExceptionEx1;

public class JavaExceptionEx1 {
    public static void main(String[] args) throws CannotDivideBy0Exception {
        Divide.divide(10, 0);
    }

}
