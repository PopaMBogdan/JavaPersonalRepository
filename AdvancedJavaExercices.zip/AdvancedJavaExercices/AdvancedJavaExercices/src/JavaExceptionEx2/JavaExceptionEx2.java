package JavaExceptionEx2;

import java.util.List;

public class JavaExceptionEx2 {
    public static void main(String[] args) throws NoBookFoundException {

        BookRepository bookRepository = new BookRepository();
        bookRepository.add(new Book("3323-423ds", "Harry Potter Part.1", "J.K. Rowlings"));
        bookRepository.add(new Book("3323-456dt", "Harry Potter Part.2", "J.K. Rowlings"));
        bookRepository.add(new Book("3323-459dz", "Harry Potter Part.3", "J.K. Rowlings"));
        List<Book> book = bookRepository.findByName("Harry Potter Part.1");
        Book book1 = bookRepository.findByIsbn("3323-456dt");
        bookRepository.delete("3323-459dz");
        System.out.println(book1);
        System.out.println(book);
        System.out.println(bookRepository);


    }
}
