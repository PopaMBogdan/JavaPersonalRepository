package JavaExceptionEx2;

public class NoBookFoundException extends Exception {

    public NoBookFoundException(String message) {
        super("Can't find any book under this criteria of search!");
    }
}
