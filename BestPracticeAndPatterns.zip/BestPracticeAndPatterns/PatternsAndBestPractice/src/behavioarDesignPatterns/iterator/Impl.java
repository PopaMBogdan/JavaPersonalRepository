package behavioarDesignPatterns.iterator;

import java.util.List;

public class Impl implements PatternIterator {

    List lista;
    int currentIndex;
    Pattern pattern;

    public Impl(List lista) {
        this.lista = lista;
    }

    public Pattern nextPattern() {
        pattern = (Pattern)lista.get(currentIndex);
        currentIndex++;
        return pattern;
    }

    @Override
    public boolean isLastPattern() {
        return currentIndex >= lista.size();
    }
}
