package behavioarDesignPatterns.iterator;

import java.util.List;

public class Main {
    public static void main(String[] args) {


        Pattern pattern1 = new Pattern("name1", "1");
        Pattern pattern2 = new Pattern("name2", "2");
        Pattern pattern3 = new Pattern("name3", "3");

        Impl implementare = new Impl(List.of(pattern1, pattern2, pattern3));

        while (!implementare.isLastPattern()) {
            System.out.println(implementare.nextPattern());

        }
    }
}