package behavioarDesignPatterns.iterator;

public interface PatternIterator {

    Pattern nextPattern();

    boolean isLastPattern();


}
