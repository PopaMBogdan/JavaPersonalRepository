package behavioarDesignPatterns.strategy;

public class Cash implements Payment{

    @Override
    public void pay(double amount) {
        System.out.println("pay with Cash. Amount : " + amount);
    }

    public Cash() {
    }
}
