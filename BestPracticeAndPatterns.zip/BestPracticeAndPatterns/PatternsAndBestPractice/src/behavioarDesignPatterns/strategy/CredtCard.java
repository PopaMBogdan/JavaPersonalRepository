package behavioarDesignPatterns.strategy;

import java.time.LocalDate;

public class CredtCard implements Payment{

    private String fullName;
    private String cardNumber;
    private String cvv;
    private LocalDate dateOfExpiry;

    public CredtCard(String fullName, String cardNumber, String cvv, LocalDate dateOfExpiry) {
        this.fullName = fullName;
        this.cardNumber = cardNumber;
        this.cvv = cvv;
        this.dateOfExpiry = dateOfExpiry;
    }



    public CredtCard() {
    }

    @Override
    public void pay(double amount) {
        System.out.println("pay with CrediCart. Amount : " + amount);
    }
}
