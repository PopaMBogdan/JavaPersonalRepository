package behavioarDesignPatterns.strategy;

public interface Payment {
    void pay(double amount);

}
