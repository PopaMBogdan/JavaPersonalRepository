package behavioarDesignPatterns.strategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Pizza {

    private List<Ingredient> ingredients;
    private double amount;

    public Pizza() {
        ingredients = new ArrayList<>();
    }

    public void addIngredient(Ingredient ingredient){
        if(ingredient !=null) {
            ingredients.add(ingredient);
        }
    }

    public void addIngredient(Optional<Ingredient> optionalIngredient){
        optionalIngredient.ifPresent(ingredient -> ingredients.add(ingredient));
    }

    public void removeIngredient(Optional<Ingredient> optionalIngredient){
        optionalIngredient.ifPresent(ingredient -> ingredients.remove(ingredient));
    }

    public double calculateTotal(){
        double sum = 0;
        for (Ingredient ingredient : ingredients){
            sum += ingredient.getPrice();
        }
        return sum;
    }

    public double calculateTotalWithStream(){
        double sum = 0;
        return ingredients.stream().map(Ingredient :: getPrice).reduce(sum,(price,intermediateSum) -> Double.sum(price,intermediateSum));

    }

    public void pay(Payment payment){
        payment.pay(calculateTotalWithStream()); // aici se face compozitia cu interfata Payment. Pizza HAS A Payment!!!
        // aici sunt encapsulati toate strategiile de plata, sub pay(Payment)

    }


}
