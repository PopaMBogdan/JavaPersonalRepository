package behavioarDesignPatterns.strategy;

import java.time.LocalDate;

public class Strategy {
    public static void main(String[] args) {

        Pizza pizza = new Pizza();
        pizza.addIngredient(new Ingredient("Sunca",5.00));
        pizza.addIngredient(new Ingredient("branza",2.00));
        pizza.addIngredient(new Ingredient("aluat",8.00));

        pizza.pay(new CredtCard("Popa Bogdan","45612345612365","015", LocalDate.now()));
        pizza.pay(new Cash());




    }


}
