package behavioarDesignPatterns.template_method;

public class Capriciosa extends Pizza{

    @Override
    public void addIngredients() {
        System.out.println("I'm adding Capriciosa ingredients");
    }


}
