package behavioarDesignPatterns.template_method;

public abstract class Pizza {
    public void bakingPizza(){
        System.out.println("baking Pizza");
        formingDough();
        addIngredients();
        bakingDouth();
        System.out.println("Pizza is baked");
    }

    private void formingDough(){
        System.out.println("forming Dough");
    }

    private void bakingDouth(){
        System.out.println("baking Dought");
    }

    protected abstract void addIngredients();
}
