package behavioarDesignPatterns.template_method;

public class TemplateMethod {
    public static void main(String[] args) {
        Pizza pizza1 = new Margherita();
        Pizza pizza2 = new Capriciosa();

        pizza1.bakingPizza();
        pizza2.bakingPizza();



    }
}
