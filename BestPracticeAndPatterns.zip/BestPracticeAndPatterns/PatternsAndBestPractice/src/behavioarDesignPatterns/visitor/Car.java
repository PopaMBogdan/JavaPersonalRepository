package behavioarDesignPatterns.visitor;

public class Car implements Item {

    private String brand;
    private String color;
    private double price;

    public Car(String brand, String color, double price) {
        this.brand = brand;
        this.color = color;
        this.price = price;
    }

    public String getBrand() {
        return brand;
    }

    public String getColor() {
        return color;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public double accept(ShoppingCart visitor) {

        return visitor.visit(this);
    }
}