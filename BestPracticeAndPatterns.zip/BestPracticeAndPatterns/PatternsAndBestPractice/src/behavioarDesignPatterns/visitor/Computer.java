package behavioarDesignPatterns.visitor;
public class Computer implements Item{

    private String ram;
    private String hdd;
    private String cpu;
    private double price;

    public Computer(String ram, String hdd, String cpu, double price) {
        this.ram = ram;
        this.hdd = hdd;
        this.cpu = cpu;
        this.price = price;
    }

    public String getRam() {
        return ram;
    }

    public String getHdd() {
        return hdd;
    }

    public String getCpu() {
        return cpu;
    }

    public double getPrice() {
        return price;
    }

    @Override
    public double accept(ShoppingCart visitor) {

        return visitor.visit(this);
    }
}
