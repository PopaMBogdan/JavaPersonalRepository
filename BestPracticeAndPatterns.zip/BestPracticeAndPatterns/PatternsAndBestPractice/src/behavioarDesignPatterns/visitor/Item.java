package behavioarDesignPatterns.visitor;

public interface Item {
    double accept(ShoppingCart visitor);

}
