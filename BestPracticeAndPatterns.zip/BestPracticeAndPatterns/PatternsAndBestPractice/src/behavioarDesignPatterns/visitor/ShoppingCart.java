package behavioarDesignPatterns.visitor;

public interface ShoppingCart {

double visit(Car car);
double visit(Computer computer);
}
