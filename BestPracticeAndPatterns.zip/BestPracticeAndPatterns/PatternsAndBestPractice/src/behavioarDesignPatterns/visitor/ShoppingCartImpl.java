package behavioarDesignPatterns.visitor;

public class ShoppingCartImpl implements ShoppingCart {
    @Override
    public double visit(Car car) {

        System.out.println("Business logic for Car object!");

        String color = car.getColor() ;
        double price = car.getPrice();

        if(color.equalsIgnoreCase("white")) {
            price -= 1000;
        }

        System.out.println("The car with brand " + car.getBrand()
                + " and color " + car.getColor() + "with price "+
                price);
        return price;
    }

    @Override
    public double visit(Computer computer) {
        System.out.println("Business logic for a Computer object!");
        System.out.println("Computer with " + computer.getRam() + " ram"+
                "and " + computer.getPrice() + " price.");
        return computer.getPrice();
    }
}

