package behavioarDesignPatterns.visitor;

import java.util.ArrayList;
import java.util.List;

public class Vizitor {
    private static ShoppingCart shoppingCart = new ShoppingCartImpl();

    public static void main(String[] args) {

        List<Item> list = new ArrayList<>();

        list.add(new Car("Dacia","WhiTe",7000.00));
        list.add(new Car("BMW","black",40000.00));

        list.add(new Computer("4GB","1TB","x64 2.3 Ghz",1200.00));
        list.add(new Computer("8GB","2TB","x64 2.7 Ghz",1800.00));

        double sum = 0;


        for (Item item : list) {
            sum += item.accept(shoppingCart);
        }
        System.out.println("Total price for your shopping chart is : " + sum);
    }
}