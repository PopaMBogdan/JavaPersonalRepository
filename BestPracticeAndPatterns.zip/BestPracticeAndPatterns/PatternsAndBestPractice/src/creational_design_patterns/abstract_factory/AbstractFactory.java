package creational_design_patterns.abstract_factory;

import java.util.Optional;

public class AbstractFactory {
    public static void main(String[] args) {

        Pizza pizzaTest1 = PizzaFactory.createPizza("Margherita", 23.5).get();
        Pizza pizzaTest2 = PizzaFactory.createPizza("Capriciosa", 23.5).orElse(pizzaTest1);

        System.out.println(pizzaTest1);
        System.out.println(pizzaTest2);

        Optional<Pizza> pizzaTest3 = PizzaFactory.createPizza("Margherita", 23.5);

        if (pizzaTest3.isPresent()){
            System.out.println(pizzaTest3.get());
        }
    }

}
