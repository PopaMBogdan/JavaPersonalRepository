package creational_design_patterns.abstract_factory;

public class Capriciosa extends Pizza{

    private double size;

    public Capriciosa(double size) {
        this.size = size;
    }

    @Override
    public String getName() {
        return "Capriciosa";
    }

    @Override
    public Double getSize() {
        return size;
    }

    @Override
    public String getIngrediens() {
        return "Cheese, Souse, Ham, Champignon";
    }
}
