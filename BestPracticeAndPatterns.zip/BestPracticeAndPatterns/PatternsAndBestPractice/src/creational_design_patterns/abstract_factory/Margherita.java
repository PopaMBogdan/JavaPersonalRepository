package creational_design_patterns.abstract_factory;

public class Margherita extends Pizza {


    private double size;

    public Margherita(double size) {
        this.size = size;
    }

    @Override
    public String getName() {
        return "Margherita";
    }

    @Override
    public Double getSize() {
        return size;
    }

    @Override
    public String getIngrediens() {
        return "Cheese Souse";
    }

}
