package creational_design_patterns.abstract_factory;

public class MargheritaFactory implements PizzaAbstractFactory{
    @Override
    public Pizza create(double size) {
        return new Margherita(size);
    }
}
