package creational_design_patterns.abstract_factory;

public abstract class Pizza {

    public abstract String getName();

    public abstract Double getSize();

    public abstract String getIngrediens();

public String toString() {
    return "Pizza --> " + getName() + " -- " +getSize();
}
}


