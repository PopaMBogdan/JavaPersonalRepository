package creational_design_patterns.abstract_factory;

public interface PizzaAbstractFactory {

    Pizza create(double size);
}
