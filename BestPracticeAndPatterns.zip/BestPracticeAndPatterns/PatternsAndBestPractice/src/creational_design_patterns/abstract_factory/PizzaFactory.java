package creational_design_patterns.abstract_factory;

import java.util.Optional;

public class PizzaFactory {

    public static Optional<Pizza> createPizza(String type, double size){
        switch(type){
            case "Margherita":
                return Optional.of(new MargheritaFactory().create(size));
            case "Capriciosa":
                return Optional.of(new CapriciosaFactory().create(size));
        }
        return Optional.empty();
    }
}
