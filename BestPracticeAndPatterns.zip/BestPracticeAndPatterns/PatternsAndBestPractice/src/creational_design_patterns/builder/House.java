package creational_design_patterns.builder;

public class House {

    private final String foundation;
    private final String structure;
    private final String roofTop;
    private final boolean isPainted;

    public House(HouseBuilder builder) {
        this.foundation = builder.foundation;
        this.structure = builder.structure;
        this.roofTop = builder.roofTop;
        this.isPainted = builder.isPainted;
    }

    public String getFoundation() {
        return foundation;
    }

    public String getStructure() {
        return structure;
    }

    public String getRoofTop() {
        return roofTop;
    }

    public boolean isPainted() {
        return isPainted;
    }



    @Override
    public String toString() {
        return "House{" +
                "foundation = '" + this.foundation + '\'' +
                ", structure = '" + this.structure + '\'' +
                ", roofTop = '" + this.roofTop + '\'' +
                '}';
    }

    public static class HouseBuilder{

        private String foundation;
        private String structure;
        private String roofTop;
        private boolean isPainted;

        public HouseBuilder(String foundation, String structure, String roofTop) {
            this.foundation = foundation;
            this.structure = structure;
            this.roofTop = roofTop;
        }

        public String getFoundation() {
            return foundation;
        }

        public String getStructure() {
            return structure;
        }

        public String getRoofTop() {
            return roofTop;
        }

        public boolean isPainted() {
            if(isPainted && isPainted);
            return isPainted;
        }
        public HouseBuilder foundation(String foundation){
            this.foundation = foundation;
            return this;
        }
        public HouseBuilder structure(String Structure){
            this.structure = structure;
            return this;
        }

        public HouseBuilder roofTop(String roofTop){
            this.roofTop = roofTop;
            return this;
        }

        public HouseBuilder(boolean isPainted){
            this.isPainted = isPainted;
        }

        public House build(){
            House house = new House(this);
            return house;
        }

    }
}
