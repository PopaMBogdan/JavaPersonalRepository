package creational_design_patterns.builder;

public class Main {
    public static void main(String[] args) {

        House house1 = new House.HouseBuilder("concreet", "briques", "tuile").build();
        House house2 = new House.HouseBuilder("Rocks and concreet","concreet","metal board").build();
        House house3 = new House.HouseBuilder(true).build();

        System.out.println("House one before paint" + house1);
        System.out.println("House two before paint" + house2);
        System.out.println("House tree before paint" + house3);

    }
}
