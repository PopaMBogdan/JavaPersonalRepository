package creational_design_patterns.decorator;

import java.util.ArrayList;

public class BasicPizza implements Pizza{

    ArrayList<String> ingredients;

    public BasicPizza() {
        ingredients = new ArrayList<>();
        addIngredients("Aluat");
        addIngredients("Sos de rosii");

    }

    @Override
    public void addIngredients(String ingredient) {
       ingredients.add(ingredient);
    }

    @Override
    public void printIngredients() {
        //System.out.println("Ingredientele folosite sunt : " + ingredients);
        System.out.println(" Pizza contine: " + String.join(",", ingredients));//returneaza toate elementele din lista ingredients
    }
}
