package creational_design_patterns.decorator;

public class Decorator {
    public static void main(String[] args) {

        Pizza pizza = new BasicPizza();
        pizza.printIngredients();

        HamPizza hamPizza = new HamPizza(pizza);
        hamPizza.printIngredients();

        MushroomsPizza mushroomsPizza = new MushroomsPizza(pizza);
        mushroomsPizza.printIngredients();

        Pizza pizzaTest = new HamPizza(new MushroomsPizza(new BasicPizza()));
        pizzaTest.printIngredients();
    }
}
