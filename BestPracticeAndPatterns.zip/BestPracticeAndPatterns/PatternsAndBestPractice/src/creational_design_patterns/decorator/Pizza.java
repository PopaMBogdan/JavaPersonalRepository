package creational_design_patterns.decorator;

public interface Pizza {
    void addIngredients(String ingredient);
    void printIngredients();

}
