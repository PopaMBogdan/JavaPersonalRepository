package creational_design_patterns.decorator;

public class PizzaDecorator implements Pizza {

    private Pizza pizza;

    public PizzaDecorator(Pizza pizza) {
        this.pizza = pizza;
    }

    @Override
    public void addIngredients(String ingredient) {
        pizza.addIngredients(ingredient);

    }

    @Override
    public void printIngredients() {
        pizza.printIngredients();

    }
}
