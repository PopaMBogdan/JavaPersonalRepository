package creational_design_patterns.desing_patterns_rescriere_metoda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Main {


    public static void main(String[] args) {
    }

    public List<Integer> stringsToInts(List<String> strings) {
        if (strings != null) {
            List<Integer> integers = new ArrayList<>();
            for (String s : strings){
                integers.add(Integer.parseInt(s));
        }
        return integers;
    } else

    {
        return null;
    }
}


    //Aceeasi metoda de sus dar simplificata si scrisa incat sa nu returneze null ci mi de graba o lista goala!


    public List<Integer> stringsToInts1(List<String> strings) {
        return strings == null ?
                Collections.EMPTY_LIST : strings.stream()
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());
        }
}
