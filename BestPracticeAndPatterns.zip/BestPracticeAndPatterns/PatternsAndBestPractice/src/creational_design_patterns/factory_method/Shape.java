package creational_design_patterns.factory_method;

public interface Shape {
    void draw();
}
