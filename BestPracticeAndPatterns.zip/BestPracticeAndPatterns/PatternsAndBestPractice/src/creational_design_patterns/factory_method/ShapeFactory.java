package creational_design_patterns.factory_method;

public class ShapeFactory{

    public Shape getShape(ShapeType shape) {
        if (shape == null) {
            return null;
        }
        if (shape == ShapeType.CIRCLE) {
            return new Circle();
        }
        else if (shape == ShapeType.SQUARE) {
            return new Square();
        }
        else if(shape == ShapeType.RECTANGLE){
            return new Rectangle();
        }
        return null;
    }




}


