package creational_design_patterns.factory_method;

public enum ShapeType {
    CIRCLE, SQUARE, RECTANGLE
}
