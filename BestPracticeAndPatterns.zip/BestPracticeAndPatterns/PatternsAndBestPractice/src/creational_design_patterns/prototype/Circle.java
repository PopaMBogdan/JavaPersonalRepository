package creational_design_patterns.prototype;

public class Circle extends Shape{

    public Circle(){
        shape = "Circle";
    }


    @Override
    void draw() {
        System.out.println("In Circle");
    }
}
