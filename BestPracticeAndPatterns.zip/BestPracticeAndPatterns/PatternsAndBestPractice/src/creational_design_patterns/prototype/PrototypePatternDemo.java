package creational_design_patterns.prototype;

public class PrototypePatternDemo {
    public static void main(String[] args) {
        ShapeCatch.loadCatch();

        Shape clonedShape1 = (Shape) ShapeCatch.getShape("1");
        System.out.println("Shape : " + clonedShape1.getShape());

        Shape clonedShape2 = (Shape) ShapeCatch.getShape("2");
        System.out.println("Shape : " + clonedShape2.getShape());

        Shape clonedShape3 = (Shape) ShapeCatch.getShape("3");
        System.out.println("Shape : " + clonedShape3.getShape());

    }
}
