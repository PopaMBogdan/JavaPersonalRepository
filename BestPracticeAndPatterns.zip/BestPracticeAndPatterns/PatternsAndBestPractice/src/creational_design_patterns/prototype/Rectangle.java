package creational_design_patterns.prototype;

public class Rectangle extends Shape{

    public Rectangle(){
        shape = "Rectangle";
    }

    @Override
    void draw() {
        System.out.println("In Rectangle");

    }
}
