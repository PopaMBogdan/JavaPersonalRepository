package creational_design_patterns.prototype;

public class Square extends Shape{

    public Square(){
        shape = "Square";
    }

    @Override
    void draw() {
        System.out.println("In Square");
    }
}
