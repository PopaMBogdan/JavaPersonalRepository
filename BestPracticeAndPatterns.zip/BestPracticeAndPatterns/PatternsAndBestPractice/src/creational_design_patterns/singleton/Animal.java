package creational_design_patterns.singleton;

public class Animal {

    private static Animal animal = null;
    private String type;


    private Animal() {
    }
    public synchronized static Animal getInstance(){
        if(animal ==null){
            animal = new Animal();
        }
        return animal;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
