package creational_design_patterns.singleton;

public class Main {
    public static void main(String[] args) {
        Animal animal = Animal.getInstance();
        animal.setType("lyon");
        System.out.println(animal.getType());
        animal.setType("monkey");
        System.out.println(animal.getType());
        animal.setType("Deer");
        System.out.println(animal.getType());
    }
}
