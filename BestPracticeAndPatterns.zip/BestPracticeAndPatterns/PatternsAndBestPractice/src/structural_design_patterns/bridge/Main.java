package structural_design_patterns.bridge;

import structural_design_patterns.bridge.abstraction.Bike;
import structural_design_patterns.bridge.abstraction.Bus;
import structural_design_patterns.bridge.abstraction.Vehicle;
import structural_design_patterns.bridge.implementation.Assemble;
import structural_design_patterns.bridge.implementation.Produce;

public class Main {
    public static void main(String[] args) {

        Vehicle vehicle = new Bus(new Assemble(),new Produce());
        Vehicle vehicle1 = new Bike(new Assemble(),new Produce());

        vehicle.manufacture();
        vehicle1.manufacture();
    }
}
