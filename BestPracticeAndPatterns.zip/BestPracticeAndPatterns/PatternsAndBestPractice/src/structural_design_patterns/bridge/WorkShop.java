package structural_design_patterns.bridge;

public interface WorkShop {

    void work();
}
