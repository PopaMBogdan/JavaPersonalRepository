package structural_design_patterns.bridge.abstraction;

import structural_design_patterns.bridge.WorkShop;

public class Bike extends Vehicle {

    public Bike(WorkShop workshopProduce, WorkShop workshopeAssemble) {
        super(workshopProduce, workshopeAssemble);
    }

    @Override
    public void manufacture() {
        System.out.println("Bike");
        workshopeAssemble.work();
        workshopProduce.work();
    }


}
