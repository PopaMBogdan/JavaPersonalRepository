package structural_design_patterns.bridge.abstraction;

import structural_design_patterns.bridge.WorkShop;

public class Bus extends Vehicle {
    public Bus(WorkShop workshopProduce, WorkShop workshopeAssemble) {
        super(workshopProduce, workshopeAssemble);
    }

    @Override
    public void manufacture() {
        System.out.println("Bus");
        workshopeAssemble.work();
        workshopProduce.work();
    }
}
