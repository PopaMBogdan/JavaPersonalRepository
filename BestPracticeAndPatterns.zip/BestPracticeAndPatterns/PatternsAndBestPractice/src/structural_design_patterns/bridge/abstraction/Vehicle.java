package structural_design_patterns.bridge.abstraction;

import structural_design_patterns.bridge.WorkShop;

public abstract class Vehicle {

    WorkShop workshopProduce;
    WorkShop workshopeAssemble;

    public Vehicle(WorkShop workshopProduce, WorkShop workshopeAssemble) {
        this.workshopProduce = workshopProduce;
        this.workshopeAssemble = workshopeAssemble;
    }

    public abstract void manufacture();

}
