package structural_design_patterns.bridge.implementation;

import structural_design_patterns.bridge.WorkShop;


public class Produce implements WorkShop {
    @Override
    public void work() {
        System.out.println("Producing");
    }
}
