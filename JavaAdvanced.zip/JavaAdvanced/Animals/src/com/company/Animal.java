package com.company;

public abstract class Animal {
    int numberOfLegs;
}

