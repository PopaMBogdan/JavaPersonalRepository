package com.company;

public interface CanPlay {
    void play();

    void sleep();//putem avea si mai multe metode intr-o singura interfata
}


