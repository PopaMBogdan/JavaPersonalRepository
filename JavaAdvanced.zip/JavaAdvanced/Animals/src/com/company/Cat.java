package com.company;

public class Cat extends Dog implements CanPlay {


    public Cat () {
        super();
        System.out.println("Aici avem constructorul neparametrizat al clasei Dog");
    }

    public void sleep () {
        System.out.println("aici dorm");
    }
    @Override
    public void eat(int quantity) {
        System.out.println(quantity/2);
        super.eat(quantity);
    }

    @Override
    public void play() {
        System.out.println("Aici se joaca Cat");
        super.play();
    }

    @Override
    public int showHealth() {
        System.out.println("Metoda abstracta showHealth din Pet primeste blocul de cod in Cat");//metoda abstracta primeste body aici
        return 2;
    }
}
