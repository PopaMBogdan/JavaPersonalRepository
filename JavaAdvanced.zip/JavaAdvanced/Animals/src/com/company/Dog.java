package com.company;

import java.util.Scanner;

public class Dog extends Pet implements CanPlay {


    @Override // aici am apelat metoda eat din clasa Pet.
    public void eat() {
        System.out.println("A mancat Dog");//returneaza ce ii zic eu sa faca aici
        super.eat(); //super returneaza output-ul metodei eat din clasa parinte (Pet)
    }

    public void eat(int quantity) {//overload la metoda eat, are acelasi nume, dar semnatura diferita (alti parametri).
        this.setWeight(quantity);
        System.out.println(getWeight());

    }

    @Override
    public void play() {
        System.out.println("Aici se joaca Dog");//apelam metoda play din interfata CanPlay si definim ce face metoda asta
        super.play();
    }

    @Override
    public int showHealth() {
        System.out.println("aici implementez metoda abstracta showHealth din Dog");//aceeasi metoda abstracta folosita in Cat primeste alt body aici
        return 0;
    }
    public void sleep(){
        System.out.println("dorm");
    }

    public Dog() {
        super();// cu super apelam constructorii din alte clase, cu this apelam constructorii precedenti din aceeasi clasa.
        System.out.println("Clasa Dog mosteneste constructorul clasei pet");
    }
}
