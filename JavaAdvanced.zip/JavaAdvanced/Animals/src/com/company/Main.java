package com.company;

public class Main {

    public static void main(String[] args) {
    Dog dog = new Dog();
    dog.eat(2); //invoca metoda overloaded din Dog
    dog.eat(); // invoca metoda override din Dog, urmata de metoda eat din Pet
    dog.play();// in clasa dog am implementat metoda play din interfata CanPlay si i-am zis sa afiseze 'aici implementam play'

    Cat cat = new Cat();
    cat.eat(2); //invoca metoda mostenita de Dog
    cat.eat(); // Cat fiind si un pet, invoca metoda eat override din Cat + metoda din clasa Pet, nu si pe cea din Dog
    cat.play();//in clasa cat, s-a facut override pe metoda play din interfata CanPlay a Dog si am mai adaugat si 'aici se joaca pisica'

    Dog caine = new Dog(); //constructorul neparametrizat al clasei dog, il mosteneste pe cel al clasei parinte
    Cat pisica = new Cat();//constructorul neparametetrizat al clasi cat, il mosteneste pe cel al clasei Dog

    CanPlay xyz = new Dog();//
    xyz.play();//apelam metoda play implementata de Dog.
    Dog catel = (Dog) xyz;


pisica.showHealth();
caine.showHealth();

    }

}
