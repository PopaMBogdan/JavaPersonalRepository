package com.company;

public abstract  class Pet extends Animal {
    //field-urile (caracteristicile) clasei Pet
    private int age;
    private int weight;
    private String name;
    private String race;
    private String type;

    //constructorul neparametrizat al clasei
    public Pet () {
        super();
        System.out.println("Aici avem constructorul neparametrizat al clasei mama a Pet");
    }

    //constructorul parameterizat al clasei
    public Pet (int age, String name, String type, String race) {

        System.out.println("Your pet: ");
    }

    //metodele (comportamentul) clasei Pet
    public void walk () {
    }

    public void eat () {
        System.out.println("A mancat Pet");
    }

    public void play () {
        System.out.println("Aici se joaca Pet");
    }


    //getteri si setteri


    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public abstract int showHealth ();


}
