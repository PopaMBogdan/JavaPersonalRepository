public class Main {
    public static void main(String[] args) {
        AnimalMenu menu = new AnimalMenu(); // instantiaza Obiectul
        menu.menu(); // apeleaza metoda principala
    }
}
