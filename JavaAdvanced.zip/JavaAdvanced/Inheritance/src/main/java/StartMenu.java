public interface StartMenu {
    void menu(); // efectueeaza un contract ca metoda Animal menu sa contina metoda menu
}
