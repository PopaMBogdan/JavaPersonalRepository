package inheritance;

public class Animal extends AnimalService implements AnimalLocation {

    private String location;

    static {
        System.out.println("Calling an anonymus static block from Animal Class!");
    }

    {
        System.out.println("Calling an anonymous NON static block from Animal Class!");
    }

    static {
        System.out.println("Calling the second anonymous static block from Animal Class!");
    }

    public static void testStaticBlocks(){
        System.out.println("Calling the testStaticBlocks method inside Animal class");
    }

    public Animal() {
        super();
        System.out.println("Calling the Animal Constructor without parameters!");
    }

    public Animal(String location) {
        System.out.println("Calling the Animal Constructor with location parameter!");
        this.location = location;
    }

    public void makeNoise(String noise){
        System.out.println("Calling makeNoise() method from Animal Class!");
        System.out.println("Animal make noises : " + noise);
    }

    public void makeNoise(){
        System.out.println("Calling Overrloaded method makeNoise() from Animal Class!");
        System.out.println("No noise --- ");
    }

    @Override
    public void defineAnimalLocation() {
        System.out.println("Calling defineAnimalLocation() method implementation " +
                "inside of the Animal class! Your animal location is : " + location);
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public void setAnimalSkin() {
        System.out.println("Setting animal skin inside of Animal Class");
    }
}
