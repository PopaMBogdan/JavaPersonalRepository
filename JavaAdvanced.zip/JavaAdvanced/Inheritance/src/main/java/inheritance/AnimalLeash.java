package inheritance;

public class AnimalLeash {
    private String color;

    public AnimalLeash(String color) {
        System.out.println("Calling AnimalLeash costructor!");
        this.color = color;
    }
}
