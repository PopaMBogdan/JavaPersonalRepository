package inheritance;

public interface AnimalLocation {
    void defineAnimalLocation();
}
