package inheritance;

public abstract class AnimalService {

    public void checkAnimalLegs(){
        System.out.println("Checking Animal numbers of legs!");
    }

    public abstract void setAnimalSkin();

}
