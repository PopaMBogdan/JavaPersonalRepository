package inheritance;

public class BracDog extends Dog {

    private AnimalLeash dogLeash;

    public AnimalLeash getDogLeash() {
        return dogLeash;
    }

    public BracDog() {
        super();
        System.out.println("Calling BracDog Constructor without parameters ! ");
    }

    static {
        System.out.println("Calling an anonymus NON static block from BracDog Class!");
    }

    {
        System.out.println("Calling an anonymus static block from BracDog Class!");
        dogLeash = new AnimalLeash("Green");
    }
}
