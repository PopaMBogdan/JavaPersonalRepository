package inheritance;

public class Cat extends Animal implements AnimalLocation {

    private String breed;
    private final String noise = "Miau";

    public Cat() {
        super();
        System.out.println("Calling no parameters Cat Constructor!");
    }

    public Cat(String breed) {
        System.out.println("Calling Cat Constructor with breed parameter!");
        this.breed = breed;
    }

    static {
        System.out.println("Calling an anonymus static block from Cat Class!");
    }

    {
        System.out.println("Calling an anonymus NON static block from Cat Class!");
    }

    @Override
    public void defineAnimalLocation() {
        System.out.println("Calling defineAnimalLocation() method implementation " +
                "from Cat class! Your cat location is : " + super.getLocation());
    }

    @Override
    public void makeNoise() {
        System.out.println("Calling overrided method makeNoise() from Cat object");
        super.makeNoise(this.noise);
    }

    public String getNoise() {
        return "You are not a Cat so you are not allowed to Miau! See ya :)";
    }
}
