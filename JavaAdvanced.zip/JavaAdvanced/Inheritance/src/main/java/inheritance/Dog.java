package inheritance;

public class Dog extends Animal{

    private String location;
    private final String noise = "Woww";

    public Dog() {
        super();
        System.out.println("Calling no parameters Dog Constructor");
    }

    static {
        System.out.println("Calling an anonymus static block from Dog Class!");
    }

    {
        System.out.println("Calling an anonymus NON static block from Dog Class!");
    }

    @Override
    public void defineAnimalLocation() {
        System.out.println("Calling defineAnimalLocation() method implementation " +
                "from Dog class! Your dog location is : " + location);
    }

    @Override
    public void makeNoise() {
        System.out.println("Calling overrided method makeNoise() from Dog object");
        super.makeNoise(this.noise);
    }

    public String getNoise() {
        return "You are not a Cat so you are not allowed to Miau! See ya :)";
    }
}
