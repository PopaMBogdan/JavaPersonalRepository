package inheritance;

public class DogWithoutLocation extends Dog{
    @Override
    public void setLocation(String location) {
    }
}
