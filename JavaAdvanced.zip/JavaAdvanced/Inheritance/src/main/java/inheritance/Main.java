package inheritance;

public class Main {

    public static void main(String[] args) {

        // Animal object instance with no param Constructor
        Animal.testStaticBlocks();
        System.out.println("End of test for anonymous static blocks!\n");
        Animal testAnimal = new Animal();
        System.out.println("End Animal object initialization!\n");

        // testing inheritance with Interface and Abstract Class with no param Constructor
        testAnimal.defineAnimalLocation();
        testAnimal.setLocation("Russia");
        testAnimal.defineAnimalLocation();
        testAnimal.setAnimalSkin();
        testAnimal.checkAnimalLegs();
        System.out.println();

        // testing inheritance with Interface and param Constructor
        Animal testAnimal1 = new Animal("Turkey");
        testAnimal.defineAnimalLocation();
        System.out.println();

        // Cat object instance
        Cat testCat = new Cat();
        System.out.println("End Cat object initialization without parameters!\n");

        // testing chaining constructors in Cat class
        Cat testCat1 = new Cat("AlphaBreed");
        System.out.println("End Cat object initialization with parameters!\n");

        // YorkshireCat object instance
        YorkshireCat testYorkshireCat = new YorkshireCat();
        System.out.println("End YorkshireCat object initialization!\n");

        // Dog object instance --> Inheritance example of "is a"
        Dog testDog = new Dog();
        System.out.println("End Dog object initialization!\n");

        // BracDog object instance + Composition "has a" + static block initialization

        BracDog testBracDog = new BracDog();
        System.out.println("End BracDog object initialization!\n");
        System.out.println("Your dog leash is: " + testBracDog.getDogLeash()+"\n");

        // testing encapsulation
        testAnimal.setLocation("Brasov");
        System.out.println("Testing testAnimal location : " + testAnimal.getLocation()
        +"\n");

        testCat.setLocation("Brasov Cat");
        System.out.println("Testing testCat location : " + testCat.getLocation()
        +"\n");

        //testing compile time polymorphism --> overrloading
        testAnimal.makeNoise();
        testAnimal.makeNoise("Yuhuuuu");

        // testing runtime polymorphism --> overriding
        testCat.makeNoise();
        testYorkshireCat.makeNoise();
        testBracDog.makeNoise();
    }
}
