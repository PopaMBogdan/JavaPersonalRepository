package inheritance;

public class YorkshireCat extends Animal{

    public YorkshireCat() {
        super();
        System.out.println("Calling YorkshireCat Constructor without paramenters!");
    }

    static {
        System.out.println("Calling an anonymus static block from Yorkshire Class!");
    }

    {
        System.out.println("Calling an anonymus NON static block from Yorkshire Class!");
    }
}
