import junit.framework.TestCase;

public class CatTest extends TestCase {

    public void testSetType() {
    }

    public void testSetWeight() {
    }
}